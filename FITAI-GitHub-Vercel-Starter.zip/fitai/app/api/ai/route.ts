import OpenAI from "openai";
import { NextRequest, NextResponse } from "next/server";
import { validateTelegramInitData } from "@/lib/telegram";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "AI пока не настроен: добавь OPENAI_API_KEY в переменные окружения Vercel." }, { status: 503 });
    }

    const initData = req.headers.get("x-telegram-init-data") || "";
    if (process.env.TELEGRAM_BOT_TOKEN) {
      const valid = validateTelegramInitData(initData, process.env.TELEGRAM_BOT_TOKEN);
      if (!valid) return NextResponse.json({ error: "Не удалось подтвердить Telegram-сессию. Открой приложение через Telegram." }, { status: 401 });
    } else if (process.env.NODE_ENV === "production") {
      return NextResponse.json({ error: "На сервере не настроен Telegram Bot Token." }, { status: 503 });
    }

    const body = await req.json();
    const message = typeof body.message === "string" ? body.message.slice(0, 6000) : "";
    const image = typeof body.image === "string" ? body.image : "";
    if (!message && !image) return NextResponse.json({ error: "Добавь вопрос или фото." }, { status: 400 });
    if (image && (!image.startsWith("data:image/") || image.length > 7_000_000)) {
      return NextResponse.json({ error: "Изображение должно быть меньше 5 МБ." }, { status: 400 });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const content: any[] = [{ type: "input_text", text: message || "Проанализируй изображение еды. Оцени блюдо, примерный размер порции, калории и БЖУ. Объясни, что оценка приблизительная." }];
    if (image) content.push({ type: "input_image", image_url: image, detail: "low" });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: "Ты FITAI — доброжелательный фитнес-ассистент. Отвечай на русском, если пользователь не просит другой язык. Давай реалистичные и безопасные советы по питанию, тренировкам, восстановлению и привычкам. Не ставь диагнозы, не назначай лечение и не предлагай экстремальные диеты. При анализе еды явно помечай калории и БЖУ как приблизительную оценку. Если данных недостаточно, уточняй порцию и состав.",
      input: [{ role: "user", content }]
    });
    return NextResponse.json({ reply: response.output_text || "Не удалось сформировать ответ." });
  } catch (error) {
    console.error("FITAI AI error:", error);
    return NextResponse.json({ error: "Ошибка AI-сервиса. Проверь API-ключ и настройки модели." }, { status: 500 });
  }
}
